"use client";
import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";

export default function AdminReports({ salesData, activityLogs }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Laporan Penjualan & Aktivitas</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-gray-500">
          Laporan penjualan dan aktivitas di sini.
        </div>
      </CardContent>
    </Card>
  );
}