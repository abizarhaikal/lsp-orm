"use client";
import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { CalendarIcon, Clock, Users, Mail, Clock1 } from "lucide-react";
import { format } from "date-fns";
import { id } from "date-fns/locale";

export default function ReservationForm({ onSubmit }) {
  const [selectedDate, setSelectedDate] = useState();
  const [form, setForm] = useState({
    name: "",
    email: "",
    guests: "",
    time: "",
  });

  // Ambil data user dari localStorage (sekali saja di mount)
  useEffect(() => {
    if (typeof window !== "undefined") {
      const userStr = localStorage.getItem("user");
      if (userStr) {
        const user = JSON.parse(userStr);
        setForm((prev) => ({
          ...prev,
          name: user.name || "",
          email: user.email || "",
        }));
      }
    }
  }, []);

  const handleChange = (key, value) =>
    setForm((prev) => ({
      ...prev,
      [key]: value,
    }));

  const handleSubmit = (e) => {
    e.preventDefault();
    if (selectedDate && form.name && form.email && form.guests && form.time) {
      onSubmit({
        ...form,
        date: selectedDate,
      });
      setForm((prev) => ({
        ...prev,
        guests: "",
        time: "",
      }));
      setSelectedDate(undefined);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Nama Lengkap</Label>
            <Input
              id="name"
              value={form.name}
              readOnly
              className="bg-gray-100"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                <Mail className="h-5 w-5 " />
              </span>
              <Input
                id="email"
                value={form.email}
                readOnly
                className="bg-gray-100 pl-10"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="guests">Jumlah Tamu</Label>
            <Select
              value={form.guests}
              onValueChange={(val) => handleChange("guests", val)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Pilih jumlah tamu" />
              </SelectTrigger>
              <SelectContent>
                {[1, 2, 3, 4, 5, 6, 7, 8].map((num) => (
                  <SelectItem key={num} value={num.toString()}>
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4" />
                      {num} orang
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Tanggal Reservasi</Label>
            <Popover>
              <PopoverTrigger asChild>
                <button
                  type="button"
                  className="border w-full py-2 rounded flex items-center gap-2 text-left font-normal bg-white"
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {selectedDate
                    ? format(selectedDate, "PPP", { locale: id })
                    : "Pilih tanggal"}
                </button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>
          <div className="space-y-2">
            <Label htmlFor="time">Waktu</Label>
            <Select
              value={form.time}
              onValueChange={(val) => handleChange("time", val)}
            >
              <SelectTrigger>
                <Clock1 className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Pilih waktu" />
              </SelectTrigger>
              <SelectContent>
                {[
                  "11:00",
                  "12:00",
                  "13:00",
                  "14:00",
                  "18:00",
                  "19:00",
                  "20:00",
                  "21:00",
                ].map((time) => (
                  <SelectItem key={time} value={time}>
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4" />
                      {time}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>
      <button
        type="submit"
        className="w-full bg-primary text-white py-2 rounded font-medium"
        disabled={
          !selectedDate ||
          !form.name ||
          !form.email ||
          !form.guests ||
          !form.time
        }
      >
        Buat Reservasi
      </button>
    </form>
  );
}
