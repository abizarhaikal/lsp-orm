"use client";
import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { useState } from "react";
import { Edit } from "lucide-react";

export default function AdminTables({ tables, addTable, setTables }) {
  // State untuk form tambah meja baru
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newTable, setNewTable] = useState({
    number: "",
    capacity: "",
    location: "Indoor",
  });

  // Utility untuk status badge
  const getStatusColor = (status) => {
    switch (status) {
      case "Tersedia":
        return "bg-green-100 text-green-800";
      case "Terisi":
        return "bg-red-100 text-red-800";
      case "Reservasi":
        return "bg-yellow-100 text-yellow-800";
      case "Maintenance":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  // Handle tambah meja
  const handleAddTable = () => {
    if (!newTable.number || !newTable.capacity) return;
    addTable({
      id: tables.length + 1,
      ...newTable,
      number: Number.parseInt(newTable.number),
      capacity: Number.parseInt(newTable.capacity),
      status: "Tersedia",
      qrCode: `QR${String(tables.length + 1).padStart(3, "0")}`,
    });
    setNewTable({ number: "", capacity: "", location: "Indoor" });
    setIsDialogOpen(false);
  };

  // Handle update status meja (toggle Terisi/Kosong)
  const handleToggleStatus = (id) => {
    setTables(
      tables.map((table) =>
        table.id === id
          ? {
              ...table,
              status:
                table.status === "Terisi"
                  ? "Tersedia"
                  : table.status === "Tersedia"
                  ? "Terisi"
                  : table.status, // Only toggle if Tersedia/Terisi
            }
          : table
      )
    );
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Manajemen Meja</CardTitle>
            <span className="text-sm text-muted-foreground">
              Kelola meja dan kapasitas restoran
            </span>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button>Tambah Meja</Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Tambah Meja Baru</DialogTitle>
                <DialogDescription>Masukkan detail meja baru</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <label
                    htmlFor="tableNumber"
                    className="block text-sm font-medium"
                  >
                    Nomor Meja
                  </label>
                  <Input
                    id="tableNumber"
                    type="number"
                    value={newTable.number}
                    onChange={(e) =>
                      setNewTable({ ...newTable, number: e.target.value })
                    }
                  />
                </div>
                <div>
                  <label
                    htmlFor="tableCapacity"
                    className="block text-sm font-medium"
                  >
                    Kapasitas
                  </label>
                  <Input
                    id="tableCapacity"
                    type="number"
                    value={newTable.capacity}
                    onChange={(e) =>
                      setNewTable({ ...newTable, capacity: e.target.value })
                    }
                  />
                </div>
                <div>
                  <label
                    htmlFor="tableLocation"
                    className="block text-sm font-medium"
                  >
                    Lokasi
                  </label>
                  <Select
                    value={newTable.location}
                    onValueChange={(value) =>
                      setNewTable({ ...newTable, location: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih lokasi" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Indoor">Indoor</SelectItem>
                      <SelectItem value="Outdoor">Outdoor</SelectItem>
                      <SelectItem value="VIP">VIP</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button onClick={handleAddTable} className="w-full">
                  Simpan Meja
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {tables.map((table) => (
            <Card key={table.id} className="p-4">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h3 className="font-semibold text-lg">Meja {table.number}</h3>
                  <p className="text-sm text-gray-600">
                    Kapasitas: {table.capacity} orang
                  </p>
                  <p className="text-sm text-gray-600">
                    Lokasi: {table.location}
                  </p>
                  <p className="text-sm text-gray-600">QR: {table.qrCode}</p>
                </div>
                <Badge className={getStatusColor(table.status)}>
                  {table.status}
                </Badge>
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" className="flex-1">
                  <Edit className="h-4 w-4" /> Edit
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="flex-1"
                  onClick={() => handleToggleStatus(table.id)}
                >
                  {table.status === "Terisi"
                    ? "Kosongkan"
                    : table.status === "Tersedia"
                    ? "Set Terisi"
                    : "-"}
                </Button>
              </div>
            </Card>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
