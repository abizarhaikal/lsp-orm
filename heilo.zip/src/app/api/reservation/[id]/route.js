import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

function getId(params) {
  return params.id;
}

// GET /api/reservation/[id]
export async function GET(req, { params }) {
  const id = getId(params);
  try {
    const reservation = await prisma.reservation.findUnique({
      where: { id },
      include: {
        customer: { select: { name: true, email: true } },
      },
    });
    if (!reservation)
      return NextResponse.json({ error: "Not found" }, { status: 404 });

    return NextResponse.json(
      {
        ...reservation,
        customer_name: reservation.customer?.name ?? null,
        customer_email: reservation.customer?.email ?? null,
      },
      { status: 200 }
    );
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// PUT /api/reservation/[id]
export async function PUT(req, { params }) {
  const id = getId(params);
  try {
    const { customer_id, table_number, guest_count, status } = await req.json();

    const updated = await prisma.reservation.update({
      where: { id },
      data: {
        customer_id: customer_id || null, // null jika tidak diisi
        table_number,
        guest_count,
        status,
      },
      include: {
        customer: { select: { name: true, email: true } },
      },
    });

    return NextResponse.json(
      {
        ...updated,
        customer_name: updated.customer?.name ?? null,
        customer_email: updated.customer?.email ?? null,
      },
      { status: 200 }
    );
  } catch (err) {
    if (err.code === "P2025") {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// DELETE /api/reservation/[id]
export async function DELETE(req, { params }) {
  const id = getId(params);
  try {
    const deleted = await prisma.reservation.delete({
      where: { id },
      include: {
        customer: { select: { name: true, email: true } },
      },
    });

    return NextResponse.json(
      {
        ...deleted,
        customer_name: deleted.customer?.name ?? null,
        customer_email: deleted.customer?.email ?? null,
      },
      { status: 200 }
    );
  } catch (err) {
    if (err.code === "P2025") {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
