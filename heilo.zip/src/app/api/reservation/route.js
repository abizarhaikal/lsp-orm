import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// GET /api/reservation?customer_id=...
export async function GET(req) {
  const { searchParams } = new URL(req.url);
  const customer_id = searchParams.get("customer_id");

  try {
    let reservations;
    if (customer_id) {
      // Get reservation by customer
      reservations = await prisma.reservation.findMany({
        where: { customer_id },
        include: {
          customer: { select: { name: true, email: true } },
        },
        orderBy: [{ reservation_date: "desc" }, { reservation_time: "desc" }],
      });
    } else {
      // Get all reservations
      reservations = await prisma.reservation.findMany({
        include: {
          customer: { select: { name: true, email: true } },
        },
        orderBy: [{ reservation_date: "desc" }, { reservation_time: "desc" }],
      });
    }

    // biar response mirip dengan versi SQL kamu
    const formatted = reservations.map((r) => ({
      ...r,
      customer_name: r.customer?.name ?? null,
      customer_email: r.customer?.email ?? null,
    }));

    return NextResponse.json(formatted, { status: 200 });
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// POST /api/reservation
export async function POST(req) {
  try {
    const {
      customer_id,
      guest_count,
      reservation_date,
      reservation_time,
      status,
      table_number,
    } = await req.json();

    const newReservation = await prisma.reservation.create({
      data: {
        customer_id: customer_id || null,
        guest_count,
        reservation_date: reservation_date
          ? new Date(reservation_date)
          : undefined,
        reservation_time,
        status,
        table_number: table_number ?? null,
      },
      include: {
        customer: { select: { name: true, email: true } },
      },
    });

    return NextResponse.json(
      {
        ...newReservation,
        customer_name: newReservation.customer?.name ?? null,
        customer_email: newReservation.customer?.email ?? null,
      },
      { status: 201 }
    );
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
