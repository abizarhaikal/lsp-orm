import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// GET detail satu order
export async function GET(request, context) {
  const params = await context.params; // Await params
  const order_id = params?.order_id;

  if (!order_id) {
    return NextResponse.json({ error: "Order ID diperlukan" }, { status: 400 });
  }

  try {
    const order = await prisma.order.findUnique({
      where: { id: order_id },
      include: {
        customer: { select: { name: true, email: true } },
        orderItems: {
          include: {
            menuItem: {
              select: {
                name: true,
                price: true,
                category: true,
                imageUrl: true,
              },
            },
          },
        },
      },
    });

    if (!order) {
      return NextResponse.json(
        { error: "Order tidak ditemukan" },
        { status: 404 }
      );
    }

    return NextResponse.json({
      ...order,
      customer_name: order.customer?.name ?? null,
      items: order.orderItems.map((oi) => ({
        quantity: oi.quantity,
        menu_name: oi.menuItem?.name ?? null,
        price: oi.menuItem?.price ?? null,
        category: oi.menuItem?.category ?? null,
        imageUrl: oi.menuItem?.imageUrl ?? null,
      })),
      orderItems: undefined,
      customer: undefined,
    });
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// PUT update satu order
export async function PUT(request, context) {
  const params = await context.params; // Await params
  const order_id = params.order_id;
  if (!order_id) {
    return NextResponse.json({ error: "Order ID diperlukan" }, { status: 400 });
  }
  try {
    const body = await request.json();
    console.log("PUT /api/order/[order_id] body:", body); // Tambahkan ini

    const updated = await prisma.order.update({
      where: { id: order_id },
      data: {
        ...(body.status && { status: body.status }),
        ...(body.paymentStatus && { paymentStatus: body.paymentStatus }),
        ...(body.table_number && { table_number: body.table_number }),
        ...(body.paymentStatus && { paymentStatus: body.paymentStatus }),
      },
    });
    return NextResponse.json(updated);
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// DELETE hapus satu order
export async function DELETE(request, context) {
  const params = await context.params; // Await params
  const order_id = params?.order_id;

  if (!order_id) {
    return NextResponse.json({ error: "Order ID diperlukan" }, { status: 400 });
  }

  try {
    await prisma.order.delete({ where: { id: order_id } });
    return NextResponse.json({ message: "Order dihapus" });
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
