import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import shortid from "shortid";

// Helper: Format output order
function formatOrder(order) {
  return {
    ...order,
    paymentStatus: order.paymentStatus || "pending",
    customer_name: order.customer?.name ?? null,
    paymentMethod: order.paymentMethod || null,
    items: order.orderItems.map((oi) => ({
      quantity: oi.quantity,
      menu_name: oi.menuItem?.name ?? null,
      price: oi.menuItem?.price ?? null,
      category: oi.menuItem?.category ?? null,
      imageUrl: oi.menuItem?.imageUrl ?? null,
    })),
    orderItems: undefined,
    customer: undefined,
  };
}

// GET all orders
export async function GET(req) {
  try {
    const orders = await prisma.order.findMany({
      orderBy: { order_number: "desc" },
      include: {
        customer: { select: { name: true, email: true } },
        orderItems: {
          include: {
            menuItem: {
              select: {
                name: true,
                price: true,
                category: true,
                imageUrl: true,
              },
            },
          },
        },
      },
    });

    const formattedOrders = orders.map(formatOrder);
    return NextResponse.json(formattedOrders);
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req) {
  const {
    customer_id,
    status = "pending",
    paymentStatus = "pending",
    paymentMethod = null, // ← tambahkan ini!
    items = [],
    table,
    notes,
  } = await req.json();

  if (!items.length) {
    return NextResponse.json(
      { error: "Items tidak boleh kosong" },
      { status: 400 }
    );
  }

  const order_number = "ORD-" + shortid.generate();

  try {
    const order = await prisma.order.create({
      data: {
        order_number,
        status,
        paymentStatus,
        paymentMethod, // ← simpan ke DB
        table_number: table ? Number(table) : null,
        customer: { connect: { id: customer_id } },
        orderItems: {
          create: items.map((item) => ({
            menu_item_id: item.menu_item_id,
            quantity: item.quantity,
          })),
        },
      },
      include: {
        customer: { select: { name: true, email: true } },
        orderItems: {
          include: {
            menuItem: {
              select: {
                name: true,
                price: true,
                category: true,
                imageUrl: true,
              },
            },
          },
        },
      },
    });
    return NextResponse.json(formatOrder(order), { status: 201 });
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
