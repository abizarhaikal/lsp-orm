-- AlterTable
ALTER TABLE "Order" ADD COLUMN     "paymentMethod" VARCHAR(50);
