-- AlterTable
ALTER TABLE "MenuItem" ADD COLUMN     "imageUrl" VARCHAR(255);
