-- AlterTable
ALTER TABLE "Order" ADD COLUMN     "table_number" INTEGER;
